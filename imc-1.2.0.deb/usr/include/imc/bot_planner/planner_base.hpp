/*
  ************************************************************************\

                               C O P Y R I G H T

    Copyright © 2024 IRMV lab, Shanghai Jiao Tong University, China.
                          All Rights Reserved.

    Licensed under the Creative Commons Attribution-NonCommercial 4.0
    International License (CC BY-NC 4.0).
    You are free to use, copy, modify, and distribute this software and its
    documentation for educational, research, and other non-commercial purposes,
    provided that appropriate credit is given to the original author(s) and
    copyright holder(s).

    For commercial use or licensing inquiries, please contact:
    IRMV lab, Shanghai Jiao Tong University at: https://irmv.sjtu.edu.cn/

                               D I S C L A I M E R

    IN NO EVENT SHALL TRINITY COLLEGE DUBLIN BE LIABLE TO ANY PARTY FOR
    DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING,
    BUT NOT LIMITED TO, LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE
    AND ITS DOCUMENTATION, EVEN IF TRINITY COLLEGE DUBLIN HAS BEEN ADVISED OF
    THE POSSIBILITY OF SUCH DAMAGES.

    TRINITY COLLEGE DUBLIN DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED
    TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
    PURPOSE. THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND TRINITY
    COLLEGE DUBLIN HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
    ENHANCEMENTS, OR MODIFICATIONS.

    The authors may be contacted at the following e-mail addresses:

            YX.E.Z yixuanzhou@sjtu.edu.cn

    Further information about the IRMV and its projects can be found at the ISG web site :

           https://irmv.sjtu.edu.cn/

  \*************************************************************************
 */

/**
 * A general base class for planner interface
 * Author: YX.E.Z
 * Date: 2023/8/8
 */

#ifndef DUAL_ARM_APP_PLANNER_BASE_HPP
#define DUAL_ARM_APP_PLANNER_BASE_HPP

#include <irmv/bot_common/log/log.h>
#include "imc/bot_path_planner/path_planner.hpp"
#include "imc/bot_traj_planner/trajectory_base.hpp"
#include <yaml-cpp/yaml.h>

namespace bot_planner {
    using namespace bot_traj_planner;

    /**
     * @enum ValidatorType
     * @brief Enum for different types of validators.
     */
    enum class ValidatorType {
        MoveItFCL = 0, ///< MoveIt FCL validator.
        MoveItBullet = 1, ///< MoveIt Bullet validator.
        RosService = 2 ///< ROS service validator.
    };

    /**
     * @enum KinematicsType
     * @brief Enum for different types of kinematics solvers.
     */
    enum class KinematicsType {
        Screw = 0, ///< Screw kinematics solver.
        MoveItNumerical = 1, ///< MoveIt numerical kinematics solver.
        MoveItAnalytical = 2 ///< MoveIt analytical kinematics solver.
    };

    /**
     * @enum TrajectoryType
     * @brief Enum for different types of trajectories.
     */
    enum class TrajectoryType {
        TOTP = 0, ///< Time-optimal trajectory planning.
        IterativeSpline = 1, ///< Iterative spline trajectory.
    };

    /**
     * @class PlannerBase
     * @brief Base class for planner interface.
     */
    class PlannerBase {
    public:
        /**
         * @brief Constructor for PlannerBase.
         * @param config_path Path to the configuration file.
         */
        explicit PlannerBase(const std::string &config_path);

        /**
         * @brief Destructor for PlannerBase.
         */
        virtual ~PlannerBase();

    protected:
        bot_path_planner::PathPlannerPtr pp_; ///< Path planner pointer.
        bot_kinematics::KinematicsPtr kin_; ///< Kinematics solver pointer.
        bot_validator::ValidatorPtr val_; ///< Validator solver pointer.
        double MaxVelocityFactor {1.0}; ///< Maximum velocity factor.
        double MaxAccelerationFactor {1.0}; ///< Maximum acceleration factor.
        double MaxJerkFactor {1.0}; ///< Maximum jerk factor.
        std::string CONFIG_PATH; ///< Configuration file path.
        TrajectoryType TrajType; ///< Type of trajectory.
        TrajectoryParametersPtr TrajParamPtr; ///< Trajectory parameters pointer.
        std::vector<std::string> joint_names; ///< Joint names.

    public:
        /**
         * @brief Gets the joint names from the configuration file.
         * @return A reference to the vector of joint names.
         */
        [[nodiscard]] const std::vector<std::string> &getJointNames() const;

        /**
         * @brief Creates a unique pointer to the base class.
         * @param config_path Path to the configuration file.
         * @return A unique pointer to the base class.
         */
        static std::unique_ptr<PlannerBase> create(const std::string &config_path);

        /**
         * @brief Gets the stored kinematics solver.
         * @return A reference to the kinematics solver pointer.
         */
        const bot_kinematics::KinematicsPtr &getKinematicsPtr();

        /**
         * @brief Gets the stored validator solver.
         * @return A reference to the validator solver pointer.
         */
        const bot_validator::ValidatorPtr &getValidatorPtr();

        /**
         * @brief Gets the stored path planner solver.
         * @return A reference to the path planner pointer.
         */
        const bot_path_planner::PathPlannerPtr &getPathPlannerPtr();

        /**
         * @brief Gets the nearest valid inverse kinematics (IK) solution.
         * @param query_pose The query pose.
         * @param seeds The seed for optimization-based method.
         * @param solution Output container for the nearest valid IK solution.
         * @return OK for success.
         */
        bot_common::ErrorInfo
        getNearestValidIK(const Eigen::Isometry3d &query_pose, const Eigen::VectorXd &current_joints,
                          Eigen::VectorXd &solution);

        /**
         * @brief Solves joint-related problem with joint target.
         * @param info Output information and error code.
         * @param current_joints Current joint values.
         * @param goal_joints Goal joint values.
         * @return A unique pointer to a newly established trajectory.
         */
        TrajectoryPtr solvePTP(bot_common::ErrorInfo &info, const Eigen::VectorXd &current_joints,
                               const Eigen::VectorXd &goal_joints, bool checkCollision = false);

        /**
         * @brief Solves joint-related problem with pose target.
         * @param info Output information and error code.
         * @param current_joints Current joint values.
         * @param goal_pose Goal pose.
         * @return A unique pointer to a newly established trajectory.
         */
        TrajectoryPtr solvePTP(bot_common::ErrorInfo &info, const Eigen::VectorXd &current_joints,
                               const Eigen::Isometry3d &goal_pose, bool checkCollision = false);

        /**
         * @brief Computes the best IK path corresponding to a cartesian path.
         * @param info Output information and error code.
         * @param pose_path The given cartesian path.
         * @param seed The seed (usually the current joints).
         * @param jump_threshold The threshold, when exceeded the joint path planning fails.
         * @return A unique pointer to a newly established trajectory.
         */
        TrajectoryPtr
        solveCartesianPath(bot_common::ErrorInfo &info, const std::vector<Eigen::Isometry3d> &pose_path,
                           const Eigen::VectorXd &seed, double jump_threshold, double timeout_all,
                           bool checkCollision = false);

        /**
         * @brief Solves pose-related problem with linear path.
         * @param info Output information and error code.
         * @param current_joints Current joint values.
         * @param goal_pose Goal pose.
         * @param jump_threshold The max interval between two waypoints for the IK path.
         * @return A unique pointer to a newly established trajectory.
         */
        TrajectoryPtr
        solveLIN(bot_common::ErrorInfo &info, const Eigen::VectorXd &current_joints,
                 const Eigen::Isometry3d &goal_pose, const double &jump_threshold = 0.5, const double &timeout_all = 5,
                 bool checkCollision = true);

        /**
         * @brief Solves pose-related problem with linear path.
         * @param info Output information and error code.
         * @param current_joints Current joint values.
         * @param goal_joints Goal joints.
         * @param jump_threshold The max interval between two waypoints for the IK path.
         * @return A unique pointer to a newly established trajectory.
         */
        TrajectoryPtr
        solveLIN(bot_common::ErrorInfo &info, const Eigen::VectorXd &current_joints,
                 const Eigen::VectorXd &goal_joints, const double &jump_threshold = 0.5, const double &timeout_all = 5,
                 bool checkCollision = false);

        /**
         * @brief Solves circular path-related problem.
         * @warning The rotation vector must be orthogonal to the (first point - center).
         * @param path_query Output information and error code.
         * @param current_joints Current joint values.
         * @param center The given circular center.
         * @param rotation_vector The circular angle and rotation axis (positive in anti-clockwise direction), defined in the base frame.
         * @return A unique pointer to a newly established trajectory.
         */
        TrajectoryPtr
        solveCirc(bot_common::ErrorInfo &info, const Eigen::VectorXd &current_joints,
                  const Eigen::Vector3d &center, const Eigen::AngleAxisd &rotation_vector, double jump_threshold,
                  double timeout_all, bool checkCollision = false);

        /**
         * @brief Sets the maximum velocity factor.
         * @param value The value of maximum velocity factor.
         */
        void setMaxVelocityFactor(double value);

        /**
         * @brief Gets the maximum velocity factor.
         * @return The stored maximum velocity factor, if not set returns default value.
         */
        [[nodiscard]] double getMaxVelocityFactor() const;

        /**
         * @brief Sets the maximum acceleration factor.
         * @param value The value of maximum acceleration factor.
         */
        void setMaxAccelerationFactor(double value);

        /**
         * @brief Gets the maximum acceleration factor.
         * @return The stored maximum acceleration factor, if not set returns default value.
         */
        [[nodiscard]] double getMaxAccelerationFactor() const;

        /**
         * @brief Sets the maximum jerk factor.
         * @param value The value of maximum jerk factor.
         */
        void setMaxJerkFactor(double value);

        /**
         * @brief Gets the maximum jerk factor.
         * @return The stored maximum jerk factor, if not set returns default value.
         */
        [[nodiscard]] double getMaxJerkFactor() const;

        /**
         * @brief Sets the minimum configuration-space check distance.
         * @param value The value of minimum configuration-space check distance.
         */
        void setMinConfigCheckDistance(double value);

        /**
         * @brief Gets the minimum configuration-space check distance.
         * @return The stored minimum configuration-space check distance, if not set returns default value.
         */
        [[nodiscard]] double getMinConfigCheckDistance() const;

        /**
         * @brief Sets the minimum cartesian-space translation distance.
         * @param value The value of minimum cartesian-space translation check distance.
         */
        void setMinCartesianTransDistance(double value);

        /**
         * @brief Gets the minimum cartesian-space translation distance.
         * @return The stored minimum cartesian-space translation distance, if not set returns default value.
         */
        [[nodiscard]] double getMinCartesianTransDistance() const;

        /**
         * @brief Sets the minimum cartesian-space angle distance.
         * @param value The value of minimum cartesian angle check distance.
         */
        void setMinCartesianAngleDistance(double value);

        /**
         * @brief Gets the minimum cartesian-space angle distance.
         * @return The stored minimum cartesian-space angle distance, if not set returns default value.
         */
        [[nodiscard]] double getMinCartesianAngleDistance() const;

        /**
         * @brief Converts a path to a trajectory.
         * @param info Output information and error code.
         * @param path The path to be converted.
         * @param optional_times Optional times for the trajectory.
         * @return A unique pointer to the newly established trajectory.
         */
        TrajectoryUniquePtr convertToTrajectory(bot_common::ErrorInfo &info, const std::vector<Eigen::VectorXd> &path,
                                                const std::vector<double> &optional_times = std::vector<double> {});

    protected:
        /**
         * @brief Creates a validator from the configuration file.
         * @param node The YAML node containing the configuration.
         * @return A unique pointer to the validator.
         */
        bot_validator::ValidatorUniquePtr createValidator(const YAML::Node &node);

        /**
         * @brief Creates a kinematics solver from the configuration file.
         * @param node The YAML node containing the configuration.
         * @return A unique pointer to the kinematics solver.
         */
        bot_kinematics::KinematicsUniquePtr createKinematics(const YAML::Node &node);
    };

    typedef std::shared_ptr<PlannerBase> PlannerPtr; ///< Shared pointer to PlannerBase.
    typedef std::unique_ptr<PlannerBase> PlannerUniquePtr; ///< Unique pointer to PlannerBase.
}

#endif //DUAL_ARM_APP_PLANNER_BASE_HPP
