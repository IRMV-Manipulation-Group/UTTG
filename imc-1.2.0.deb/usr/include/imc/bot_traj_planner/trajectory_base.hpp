/*
  ************************************************************************\

                               C O P Y R I G H T

    Copyright © 2024 IRMV lab, Shanghai Jiao Tong University, China.
                          All Rights Reserved.

    Licensed under the Creative Commons Attribution-NonCommercial 4.0
    International License (CC BY-NC 4.0).
    You are free to use, copy, modify, and distribute this software and its
    documentation for educational, research, and other non-commercial purposes,
    provided that appropriate credit is given to the original author(s) and
    copyright holder(s).

    For commercial use or licensing inquiries, please contact:
    IRMV lab, Shanghai Jiao Tong University at: https://irmv.sjtu.edu.cn/

                               D I S C L A I M E R

    IN NO EVENT SHALL TRINITY COLLEGE DUBLIN BE LIABLE TO ANY PARTY FOR
    DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING,
    BUT NOT LIMITED TO, LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE
    AND ITS DOCUMENTATION, EVEN IF TRINITY COLLEGE DUBLIN HAS BEEN ADVISED OF
    THE POSSIBILITY OF SUCH DAMAGES.

    TRINITY COLLEGE DUBLIN DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED
    TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
    PURPOSE. THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND TRINITY
    COLLEGE DUBLIN HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
    ENHANCEMENTS, OR MODIFICATIONS.

    The authors may be contacted at the following e-mail addresses:

            YX.E.Z yixuanzhou@sjtu.edu.cn

    Further information about the IRMV and its projects can be found at the ISG web site :

           https://irmv.sjtu.edu.cn/

  \*************************************************************************
 */

#ifndef DUAL_ARM_APP_TRAJECTORY_BASE_HPP
#define DUAL_ARM_APP_TRAJECTORY_BASE_HPP

#include <Eigen/Core>
#include <memory>
#include <irmv/bot_common/state/error_code.h>
#include <vector>

namespace bot_traj_planner {

    /**
     * @brief Structure to hold trajectory parameters.
     */
    struct TrajectoryParameters {
    public:
        /**
         * @brief Default constructor for TrajectoryParameters.
         */
        TrajectoryParameters() = default;

        /**
         * @brief Virtual destructor for TrajectoryParameters.
         */
        virtual ~TrajectoryParameters() = default;
    };

    typedef std::shared_ptr<TrajectoryParameters> TrajectoryParametersPtr; ///< Shared pointer to TrajectoryParameters.
    typedef std::unique_ptr<TrajectoryParameters> TrajectoryParametersUniquePtr; ///< Unique pointer to TrajectoryParameters.

    /**
     * @class TrajectoryBase
     * @brief Base class for trajectory planning.
     */
    class TrajectoryBase {
    public:
        /**
         * @brief Default constructor for TrajectoryBase.
         */
        TrajectoryBase() = default;

        /**
         * @brief Virtual destructor for TrajectoryBase.
         */
        virtual ~TrajectoryBase() = default;

    public:
        /**
         * @brief Sets the names of the joints.
         * @param names Vector of joint names.
         */
        void setNames(const std::vector<std::string>& names);

        /**
         * @brief Gets the names of the joints.
         * @return Reference to the vector of joint names.
         */
        const std::vector<std::string>& getNames();

        /**
         * @brief Initializes the trajectory with constraints and converts a discrete path to a continuous trajectory.
         * @param path Path waypoints.
         * @param max_velocities Maximum velocity constraints.
         * @param max_accelerations Maximum acceleration constraints.
         * @param max_jerks Maximum jerk constraints.
         * @return OK for success, or information on why it failed.
         */
        virtual bot_common::ErrorInfo
        init(const std::vector<Eigen::VectorXd> &path, const Eigen::VectorXd &max_velocities,
             const Eigen::VectorXd &max_accelerations,
             const Eigen::VectorXd &max_jerks) = 0;

        /**
         * @brief Gets the duration of the trajectory.
         * @return Trajectory duration in seconds.
         * @throw CustomException when the trajectory is empty.
         */
        [[nodiscard]]  virtual double getDuration() const = 0;

        /**
         * @brief Computes the position at a specific time point.
         * @param sample_time The time point with respect to the start of the trajectory in seconds.
         * @return Position at the specified time. Any time greater than the trajectory duration returns the last position.
         */
        [[nodiscard]] virtual Eigen::VectorXd computePositionAt(double sample_time) const = 0;

        /**
         * @brief Computes the velocity at a specific time point.
         * @param sample_time The time point with respect to the start of the trajectory in seconds.
         * @return Velocity at the specified time. Any time greater than the trajectory duration returns the last velocity.
         */
        [[nodiscard]] virtual Eigen::VectorXd computeVelocityAt(double sample_time) const = 0;

        /**
         * @brief Computes the acceleration at a specific time point.
         * @param sample_time The time point with respect to the start of the trajectory in seconds.
         * @return Acceleration at the specified time. Any time greater than the trajectory duration returns the last acceleration.
         */
        [[nodiscard]] virtual Eigen::VectorXd computeAccelerationAt(double sample_time) const = 0;

        /**
         * @brief Computes the jerk at a specific time point.
         * @param sample_time The time point with respect to the start of the trajectory in seconds.
         * @return Jerk at the specified time. Any time greater than the trajectory duration returns the last jerk.
         */
        [[nodiscard]] virtual Eigen::VectorXd computeJerkAt(double sample_time) const = 0;

        /**
         * @brief Checks if the trajectory contains information.
         * @return True if the trajectory is empty.
         */
        [[nodiscard]] virtual bool empty() const = 0;

        /**
         * @brief Sets the scale factor for the trajectory.
         * @param val The given scale factor.
         * @return True if the scale factor is set successfully. Some types of trajectories cannot be accelerated.
         */
        virtual void setScaleFactor(double val);

        /**
         * @brief Gets the scale factor of the trajectory.
         * @return The stored scale factor.
         */
        [[nodiscard]] double getScaleFactor() const;

        /**
         * @brief Synchronizes two trajectories. The faster trajectory will be slowed down to keep synchronized.
         * @param traj2 The second trajectory to synchronize with.
         */
        void synchronizeWithTrajectory(std::shared_ptr<TrajectoryBase> &traj2);

    protected:
        double scale_factor {1.0}; ///< Scale factor for the trajectory.
        std::vector<std::string> names_{}; ///< Names of the joints in the order of the given trajectory.
    };

    typedef std::shared_ptr<TrajectoryBase> TrajectoryPtr; ///< Shared pointer to TrajectoryBase.
    typedef std::unique_ptr<TrajectoryBase> TrajectoryUniquePtr; ///< Unique pointer to TrajectoryBase.
}
#endif //DUAL_ARM_APP_TRAJECTORY_BASE_HPP
