/*
  ************************************************************************\

                               C O P Y R I G H T

    Copyright © 2024 IRMV lab, Shanghai Jiao Tong University, China.
                          All Rights Reserved.

    Licensed under the Creative Commons Attribution-NonCommercial 4.0
    International License (CC BY-NC 4.0).
    You are free to use, copy, modify, and distribute this software and its
    documentation for educational, research, and other non-commercial purposes,
    provided that appropriate credit is given to the original author(s) and
    copyright holder(s).

    For commercial use or licensing inquiries, please contact:
    IRMV lab, Shanghai Jiao Tong University at: https://irmv.sjtu.edu.cn/

                               D I S C L A I M E R

    IN NO EVENT SHALL TRINITY COLLEGE DUBLIN BE LIABLE TO ANY PARTY FOR
    DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING,
    BUT NOT LIMITED TO, LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE
    AND ITS DOCUMENTATION, EVEN IF TRINITY COLLEGE DUBLIN HAS BEEN ADVISED OF
    THE POSSIBILITY OF SUCH DAMAGES.

    TRINITY COLLEGE DUBLIN DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED
    TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
    PURPOSE. THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND TRINITY
    COLLEGE DUBLIN HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
    ENHANCEMENTS, OR MODIFICATIONS.

    The authors may be contacted at the following e-mail addresses:

            YX.E.Z yixuanzhou@sjtu.edu.cn

    Further information about the IRMV and its projects can be found at the ISG web site :

           https://irmv.sjtu.edu.cn/

  \*************************************************************************
 */

#ifndef DUAL_ARM_APP_TRAJECTORY_ITERATIVE_HPP
#define DUAL_ARM_APP_TRAJECTORY_ITERATIVE_HPP

#include "imc/bot_traj_planner/trajectory_base.hpp"
#include <irmv/bot_common//alg_factory/algorithm_factory.h>
#include "imc/bot_traj_planner/spline_base.hpp"

namespace bot_traj_planner {
    constexpr char TrajectoryIterativeName[] = "TrajectoryIterative";

    /**
     * @enum SplineType
     * @brief Enum for different types of splines.
     */
    enum class SplineType {
        Polynomial = 0, ///< Polynomial spline.
        BSpline = 1, ///< B-spline.
        Nurbs = 2, ///< NURBS spline.
        Bezier = 3, ///< Bezier spline.
    };

    /**
     * @struct IterativeSplineParameters
     * @brief Structure to hold parameters for iterative spline.
     */
    struct IterativeSplineParameters : public TrajectoryParameters {
    public:
        /**
         * @brief Constructor for IterativeSplineParameters.
         * @param constrained_acc_ Whether to constrain acceleration.
         * @param enable_jerk_ Whether to enable jerk computation.
         * @param min_stretch Whether to minimize stretch.
         * @param min_angle_change_ Minimum angle change tolerance.
         * @param type_ Type of spline.
         */
        explicit IterativeSplineParameters(bool constrained_acc_ = true, bool enable_jerk_ = false,
                                           bool min_stretch = true,
                                           const double &min_angle_change_ = 0.001,
                                           const SplineType &type_ = SplineType::Polynomial)
                : TrajectoryParameters(), constrained_acc(constrained_acc_), enable_jerk(enable_jerk_),
                  m_stretch(min_stretch),
                  min_angle_change(min_angle_change_), type(type_) {

        };
        bool constrained_acc; ///< Whether to constrain acceleration.
        bool enable_jerk; ///< Whether to enable jerk computation.
        bool m_stretch; ///< Whether to minimize stretch.
        double min_angle_change; ///< Minimum angle change tolerance.
        SplineType type; ///< Type of spline.
    };

    /**
     * @class TrajectoryIterativeSpline
     * @brief Class for iterative spline-based trajectory planning.
     */
    class TrajectoryIterativeSpline : public TrajectoryBase {
    public:
        /**
         * @brief Constructor for TrajectoryIterativeSpline.
         * @param constrained_acc Whether to constrain acceleration.
         * @param enable_jerk Whether to enable jerk computation.
         * @param m_stretch Whether to minimize stretch.
         * @param min_angle_change Minimum angle change tolerance.
         * @param type Type of spline.
         */
        explicit TrajectoryIterativeSpline(bool constrained_acc = true, bool enable_jerk = false, bool m_stretch = true,
                                           double min_angle_change = 0.001,
                                           const SplineType &type = SplineType::Polynomial);

        /**
         * @brief Default destructor for TrajectoryIterativeSpline.
         */
        ~TrajectoryIterativeSpline() override = default;

    public:
        /**
         * @brief Creates an empty trajectory.
         * @param constrained_acc Whether to constrain acceleration.
         * @param enable_jerk Whether to enable jerk computation.
         * @param min_angle_change Minimum angle change tolerance.
         * @param type Type of spline.
         * @return A unique pointer to the base class.
         */
        static TrajectoryUniquePtr
        create(bool constrained_acc = true, bool enable_jerk = false, bool m_stretch = true,
               double min_angle_change = 0.001,
               const SplineType &type = SplineType::Polynomial);

        /**
         * @brief Initializes the trajectory with constraints and converts a discrete path to a continuous trajectory.
         * @param path Path waypoints.
         * @param max_velocities Maximum velocity constraints.
         * @param max_accelerations Maximum acceleration constraints.
         * @param max_jerks Maximum jerk constraints.
         * @return OK for success, or information on why it failed.
         */
        bot_common::ErrorInfo init(const std::vector<Eigen::VectorXd> &path, const Eigen::VectorXd &max_velocities,
                                   const Eigen::VectorXd &max_accelerations, const Eigen::VectorXd &max_jerks) override;

        /**
         * @brief Initializes the trajectory with constraints and converts a discrete path to a continuous trajectory.
         * @param path Path waypoints.
         * @param initial_status Initial status (e.g., velocity, acceleration).
         * @param end_status End status (e.g., velocity, acceleration).
         * @param max_velocities Maximum velocity constraints.
         * @param max_accelerations Maximum acceleration constraints.
         * @param max_jerks Maximum jerk constraints.
         * @param enable_limit_constraint Whether to enable limit constraints.
         * @return OK for success, or information on why it failed.
         */
        bot_common::ErrorInfo
        init(const std::vector<Eigen::VectorXd> &path, const std::vector<Eigen::VectorXd> &initial_status,
             const std::vector<Eigen::VectorXd>& end_status,
             const Eigen::VectorXd &max_velocities,
             const Eigen::VectorXd &max_accelerations, const Eigen::VectorXd &max_jerks, bool enable_limit_constraint = true);

        /**
         * @brief Gets the duration of the trajectory.
         * @return Trajectory duration in seconds.
         * @throw CustomException when the trajectory is empty.
         */
        double getDuration() const override;

        /**
         * @brief Computes the position at a specific time point.
         * @param sample_time The time point with respect to the start of the trajectory in seconds.
         * @return Position at the specified time. Any time greater than the trajectory duration returns the last position.
         */
        Eigen::VectorXd computePositionAt(double sample_time) const override;

        /**
         * @brief Computes the velocity at a specific time point.
         * @param sample_time The time point with respect to the start of the trajectory in seconds.
         * @return Velocity at the specified time. Any time greater than the trajectory duration returns the last velocity.
         */
        Eigen::VectorXd computeVelocityAt(double sample_time) const override;

        /**
         * @brief Computes the acceleration at a specific time point.
         * @param sample_time The time point with respect to the start of the trajectory in seconds.
         * @return Acceleration at the specified time. Any time greater than the trajectory duration returns the last acceleration.
         */
        Eigen::VectorXd computeAccelerationAt(double sample_time) const override;

        /**
         * @brief Computes the jerk at a specific time point.
         * @param sample_time The time point with respect to the start of the trajectory in seconds.
         * @return Jerk at the specified time. Any time greater than the trajectory duration returns the last jerk.
         */
        Eigen::VectorXd computeJerkAt(double sample_time) const override;

        /**
         * @brief Checks if the trajectory contains information.
         * @return True if the trajectory is empty.
         */
        bool empty() const override;

        /**
         * @brief Sets the scale factor for the trajectory.
         * @param val The given scale factor.
         * @return True if the scale factor is set successfully. Some types of trajectories cannot be accelerated.
         */
        void setScaleFactor(double val) override;

        /**
         * @brief Gets the implementation of the spline.
         * @return A unique pointer to the spline implementation.
         */
        const std::unique_ptr<SplineBase>& getImpl();

    protected:
        /**
         * @brief Gets the factor between the obtained raw data and the limits.
         * @param raw The obtained raw data.
         * @param upper_limit The given upper limit.
         * @param lower_limit The given lower limit.
         * @param order Should be 1 for velocity, 2 for acceleration, or 3 for jerk.
         * @return The factor.
         */
        static double
        getFactor(const Eigen::VectorXd &raw, const Eigen::VectorXd &upper_limit, const Eigen::VectorXd &lower_limit,
                  int order);

    protected:
        std::unique_ptr<SplineBase> impl_; ///< Unique pointer to the spline implementation.

        const bool jerk_enabled_; ///< Whether to enable jerk and initial/final acceleration matching.
        const bool constrained_acc_; ///< Whether to constrain acceleration.
        const bool m_stretch_; ///< Whether to minimize stretch.

        const double min_angle_change_; ///< Minimum angle change tolerance.

        mutable bool is_initialized {false}; ///< Whether the trajectory is initialized.

        mutable bool is_only_one_point {false}; ///< Whether the trajectory contains only one point.

        mutable Eigen::VectorXd start_point; ///< Start point of the trajectory.

        mutable int point_size {0}; ///< Size of the points in the trajectory.

        SplineRequestPtr requestPtr; ///< Pointer to the spline request.
    };

    inline bot_common::REGISTER_ALGORITHM(TrajectoryBase, TrajectoryIterativeName, TrajectoryIterativeSpline, bool,
                                          bool, bool,
                                          double, const SplineType&);

} // bot_traj_planner

#endif //DUAL_ARM_APP_TRAJECTORY_ITERATIVE_HPP