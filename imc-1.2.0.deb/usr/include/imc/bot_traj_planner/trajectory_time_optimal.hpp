/*
  ************************************************************************\

                               C O P Y R I G H T

    Copyright © 2024 IRMV lab, Shanghai Jiao Tong University, China.
                          All Rights Reserved.

    Licensed under the Creative Commons Attribution-NonCommercial 4.0
    International License (CC BY-NC 4.0).
    You are free to use, copy, modify, and distribute this software and its
    documentation for educational, research, and other non-commercial purposes,
    provided that appropriate credit is given to the original author(s) and
    copyright holder(s).

    For commercial use or licensing inquiries, please contact:
    IRMV lab, Shanghai Jiao Tong University at: https://irmv.sjtu.edu.cn/

                               D I S C L A I M E R

    IN NO EVENT SHALL TRINITY COLLEGE DUBLIN BE LIABLE TO ANY PARTY FOR
    DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING,
    BUT NOT LIMITED TO, LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE
    AND ITS DOCUMENTATION, EVEN IF TRINITY COLLEGE DUBLIN HAS BEEN ADVISED OF
    THE POSSIBILITY OF SUCH DAMAGES.

    TRINITY COLLEGE DUBLIN DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED
    TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
    PURPOSE. THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND TRINITY
    COLLEGE DUBLIN HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
    ENHANCEMENTS, OR MODIFICATIONS.

    The authors may be contacted at the following e-mail addresses:

            YX.E.Z yixuanzhou@sjtu.edu.cn

    Further information about the IRMV and its projects can be found at the ISG web site :

           https://irmv.sjtu.edu.cn/

  \*************************************************************************
 */

#ifndef DUAL_ARM_APP_TRAJECTORY_TIME_OPTIMAL_HPP
#define DUAL_ARM_APP_TRAJECTORY_TIME_OPTIMAL_HPP

#include "imc/bot_traj_planner/trajectory_base.hpp"
#include <irmv/bot_common/alg_factory/algorithm_factory.h>

namespace bot_traj_planner {
    class TOTPImpl;

    typedef std::shared_ptr<TOTPImpl> TOTPImplPtr;

    constexpr char TrajectoryTimeOptimalName[] = "TrajectoryTimeOptimal";

    /**
     * @struct TOTPParameters
     * @brief Structure to hold parameters for time-optimal trajectory planning.
     */
    struct TOTPParameters : public TrajectoryParameters {
    public:
        /**
         * @brief Constructor for TOTPParameters.
         * @param path_tolerance_ The tolerance that may the fitted path exceed the original path.
         * @param min_angle_change_ The minimum joint angle change to identify two sets of joint values as the same one.
         */
        explicit TOTPParameters(const double &path_tolerance_ = 0.1,
                                const double min_angle_change_ = 0.001) : TrajectoryParameters(),
                                                                          path_tolerance(path_tolerance_),
                                                                          min_angle_change(min_angle_change_) {

        };

        double path_tolerance; ///< The tolerance that may the fitted path exceed the original path.
        double min_angle_change; ///< The minimum joint angle change to identify two sets of joint values as the same one.
    };

    /**
     * @class TrajectoryTOTP
     * @brief Class for time-optimal trajectory planning.
     */
    class TrajectoryTOTP : public TrajectoryBase {
    public:
        /**
         * @brief Constructor for TrajectoryTOTP.
         * @param path_tolerance The tolerance that may the fitted path exceed the original path.
         * @param min_angle_change The minimum joint angle change to identify two sets of joint values as the same one.
         */
        explicit TrajectoryTOTP(double path_tolerance = 0.1,
                                double min_angle_change = 0.001);

        /**
         * @brief Default destructor for TrajectoryTOTP.
         */
        ~TrajectoryTOTP() override = default;

    public:
        /**
         * @brief Creates an empty trajectory.
         * @param path_tolerance A tolerance to approximate the original discrete path, the bigger the smoother with a risk of unexpected collision.
         * @param min_angle_change A tolerance to delete duplicate waypoint.
         * @return A unique pointer to the base class.
         */
        static TrajectoryUniquePtr create(double path_tolerance = 0.1, double min_angle_change = 0.001);

        /**
         * @brief Initializes the trajectory with constraints and converts a discrete path to a continuous trajectory.
         * @param path Path waypoints.
         * @param max_velocities Max velocity constraints.
         * @param max_accelerations Max acceleration constraints.
         * @param max_jerks Max jerk constraints.
         * @return OK for success, or information on why it failed.
         */
        bot_common::ErrorInfo init(const std::vector<Eigen::VectorXd> &path, const Eigen::VectorXd &max_velocities,
                                   const Eigen::VectorXd &max_accelerations, const Eigen::VectorXd &max_jerks) override;

        /**
         * @brief Gets the duration of the trajectory.
         * @return Trajectory duration in seconds format.
         * @throw CustomException when the trajectory is empty.
         */
        double getDuration() const override;

        /**
         * @brief Computes the position at a specific time point.
         * @param sample_time The time point with respect to the start of the trajectory in seconds format.
         * @return Position at the specified time. Any time greater than the trajectory duration returns the last position.
         */
        Eigen::VectorXd computePositionAt(double sample_time) const override;

        /**
         * @brief Computes the velocity at a specific time point.
         * @param sample_time The time point with respect to the start of the trajectory in seconds format.
         * @return Velocity at the specified time. Any time greater than the trajectory duration returns the last velocity.
         */
        Eigen::VectorXd computeVelocityAt(double sample_time) const override;

        /**
         * @brief Computes the acceleration at a specific time point.
         * @param sample_time The time point with respect to the start of the trajectory in seconds format.
         * @return Acceleration at the specified time. Any time greater than the trajectory duration returns the last acceleration.
         */
        Eigen::VectorXd computeAccelerationAt(double sample_time) const override;

        /**
        * @brief Computes the jerk at a specific time point.
        * @param sample_time The time point with respect to the start of the trajectory in seconds format.
        * @return Jerk at the specified time. Any time greater than the trajectory duration returns the last jerk.
        */
        [[nodiscard]] Eigen::VectorXd computeJerkAt(double sample_time) const override;

        /**
         * @brief Checks if the trajectory contains information.
         * @return True if the trajectory is empty.
         */
        bool empty() const override;

        /**
         * @brief Sets the scale factor for the trajectory.
         * @param val The given scale factor.
         * @return True if the scale factor is set successfully. Some types of trajectories cannot be accelerated.
         */
        void setScaleFactor(double val) override;

    protected:
        mutable TOTPImplPtr m_trajectory; ///< Pointer to the trajectory implementation.
        mutable bool is_initialized {false}; ///< Whether the trajectory is initialized.
        const double path_tolerance_; ///< The tolerance that may the fitted path exceed the original path.
        const double min_angle_change_; ///< The minimum joint angle change to identify two sets of joint values as the same one.
        mutable bool is_only_one_point {false}; ///< Whether the trajectory contains only one point.
        mutable Eigen::VectorXd start_point; ///< Start point of the trajectory.
        mutable int point_size {}; ///< Size of the points in the trajectory.
    };

    inline bot_common::REGISTER_ALGORITHM(TrajectoryBase, TrajectoryTimeOptimalName, TrajectoryTOTP, double, double);
}

#endif //DUAL_ARM_APP_TRAJECTORY_TIME_OPTIMAL_HPP