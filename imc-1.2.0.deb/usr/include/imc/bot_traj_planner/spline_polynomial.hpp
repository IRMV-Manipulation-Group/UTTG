/*
  ************************************************************************\

                               C O P Y R I G H T

    Copyright © 2024 IRMV lab, Shanghai Jiao Tong University, China.
                          All Rights Reserved.

    Licensed under the Creative Commons Attribution-NonCommercial 4.0
    International License (CC BY-NC 4.0).
    You are free to use, copy, modify, and distribute this software and its
    documentation for educational, research, and other non-commercial purposes,
    provided that appropriate credit is given to the original author(s) and
    copyright holder(s).

    For commercial use or licensing inquiries, please contact:
    IRMV lab, Shanghai Jiao Tong University at: https://irmv.sjtu.edu.cn/

                               D I S C L A I M E R

    IN NO EVENT SHALL TRINITY COLLEGE DUBLIN BE LIABLE TO ANY PARTY FOR
    DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING,
    BUT NOT LIMITED TO, LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE
    AND ITS DOCUMENTATION, EVEN IF TRINITY COLLEGE DUBLIN HAS BEEN ADVISED OF
    THE POSSIBILITY OF SUCH DAMAGES.

    TRINITY COLLEGE DUBLIN DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED
    TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
    PURPOSE. THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND TRINITY
    COLLEGE DUBLIN HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
    ENHANCEMENTS, OR MODIFICATIONS.

    The authors may be contacted at the following e-mail addresses:

            YX.E.Z yixuanzhou@sjtu.edu.cn

    Further information about the IRMV and its projects can be found at the ISG web site :

           https://irmv.sjtu.edu.cn/

  \*************************************************************************
 */

#ifndef DUAL_ARM_APP_SPLINE_POLYNOMINAL_HPP
#define DUAL_ARM_APP_SPLINE_POLYNOMINAL_HPP
/**
 * only cubic spline is considered now
 */
#include "spline_base.hpp"

#include <irmv/bot_common/alg_factory/algorithm_factory.h>

class CubicCurve;
namespace cubic_spline {
    class CubicSplineBase;

    typedef std::shared_ptr<CubicSplineBase> CubicSplinePtr;
}

namespace bot_traj_planner {

    constexpr char SplinePolynomialName[] = "TrajectoryPolynomial";

    /**
     * @class SplinePolynomial
     * @brief Class for polynomial spline-based trajectory smoothing.
     */
    class SplinePolynomial : public SplineBase {
    public:
        /**
         * @brief Default constructor for SplinePolynomial.
         */
        SplinePolynomial() = default;

        /**
         * @brief Default destructor for SplinePolynomial.
         */
        ~SplinePolynomial() override = default;

    public:

        /**
        * @brief Initializes the B-spline smoother.
        * @param path_data The discrete path waypoints.
        * @param request Method parameters.
        */
        void init(const std::vector<Eigen::VectorXd> &path_data, SplineRequestPtr request) override;

        /**
         * @brief Computes derivatives.
         * @param t_query The time point on which the derivatives are computed.
         * @param degree The order of derivatives to be computed.
         * @param u_handle The handle to convert t into u.
         * @return The degree-order derivatives.
         */
        Eigen::VectorXd evaluateDerivative(double t_query, int degree,
                                           std::function<double(double)> u_handle) override;

        /**
         * @brief Gets the total duration of the trajectory.
         * @return The total duration of the trajectory in seconds format.
         * @throw CustomException if empty trajectory.
         */
        [[nodiscard]] double getDuration() const override;

        /**
         * @brief Re-initializes the whole trajectory with different method parameters but the same waypoints.
         * @param request The method parameters.
         */
        void reInit(const SplineRequestPtr &request) override;

    protected:
        cubic_spline::CubicSplinePtr spline; ///< Pointer to the cubic spline.
        std::shared_ptr<CubicCurve> curve; ///< Shared pointer to the cubic curve.
    };

}

#endif //DUAL_ARM_APP_SPLINE_POLYNOMINAL_HPP