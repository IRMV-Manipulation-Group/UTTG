/*
  ************************************************************************\

                               C O P Y R I G H T

    Copyright © 2024 IRMV lab, Shanghai Jiao Tong University, China.
                          All Rights Reserved.

    Licensed under the Creative Commons Attribution-NonCommercial 4.0
    International License (CC BY-NC 4.0).
    You are free to use, copy, modify, and distribute this software and its
    documentation for educational, research, and other non-commercial purposes,
    provided that appropriate credit is given to the original author(s) and
    copyright holder(s).

    For commercial use or licensing inquiries, please contact:
    IRMV lab, Shanghai Jiao Tong University at: https://irmv.sjtu.edu.cn/

                               D I S C L A I M E R

    IN NO EVENT SHALL TRINITY COLLEGE DUBLIN BE LIABLE TO ANY PARTY FOR
    DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING,
    BUT NOT LIMITED TO, LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE
    AND ITS DOCUMENTATION, EVEN IF TRINITY COLLEGE DUBLIN HAS BEEN ADVISED OF
    THE POSSIBILITY OF SUCH DAMAGES.

    TRINITY COLLEGE DUBLIN DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED
    TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
    PURPOSE. THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND TRINITY
    COLLEGE DUBLIN HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
    ENHANCEMENTS, OR MODIFICATIONS.

    The authors may be contacted at the following e-mail addresses:

            YX.E.Z yixuanzhou@sjtu.edu.cn

    Further information about the IRMV and its projects can be found at the ISG web site :

           https://irmv.sjtu.edu.cn/

  \*************************************************************************
 */

#ifndef DUAL_ARM_APP_SPLINE_BASE_HPP
#define DUAL_ARM_APP_SPLINE_BASE_HPP
#include <Eigen/Core>
#include <memory>
#include <map>
namespace bot_traj_planner {

    /**
     * @class SplineRequest
     * @brief Base class for trajectory smoother request.
     */
    class SplineRequest{
    public:
        /**
         * @brief Default constructor for SplineRequest.
         */
        SplineRequest() = default;

        /**
         * @brief Virtual destructor for SplineRequest.
         */
        virtual ~SplineRequest() = default;

    public:
        std::vector<double> overline_u_diff{}; ///< Raw time stamps.
        std::string param_option{"Centripetal"}; ///< Self-generated time stamps option.
        std::vector<Eigen::VectorXd> initial_status{}; ///< Initial velocity, acceleration, jerk, if needed.
        std::vector<Eigen::VectorXd> end_status{}; ///< End velocity, acceleration, jerk, if needed.
        std::string name{"Basic"}; ///< Name of the spline request.
        int free_flag{0}; ///< Free flag.
        bool minimize_stretch{false}; ///< Flag to minimize stretch.
    };
    typedef std::shared_ptr<SplineRequest> SplineRequestPtr; ///< Shared pointer to SplineRequest.

    /**
     * @class SplineBase
     * @brief Base class for spline-based trajectory smoothing.
     */
    class SplineBase {
    public:
        /**
         * @brief Constructor for SplineBase.
         */
        SplineBase();

        /**
         * @brief Virtual destructor for SplineBase.
         */
        virtual ~SplineBase() = default;
    protected:
        std::vector<Eigen::VectorXd> data_points{}; ///< Data points for the spline.

        std::vector<double> time_stamps{}; ///< Time stamps for the spline.

        std::map<std::string, std::function<void()>> _time_par_method_names; ///< Map of time parameterization methods.

        bool isInitialized{false}; ///< Flag to check if the spline is initialized.

    public:
        /**
         * @brief Initializes the B-spline smoother.
         * @param path_data The discrete path waypoints.
         * @param request Method parameters.
         */
        virtual void init(const std::vector<Eigen::VectorXd> &path_data, SplineRequestPtr request) = 0;

        /**
         * @brief Computes derivatives.
         * @param t_query The time point on which the derivatives are computed.
         * @param degree The order of derivatives to be computed.
         * @param u_handle The handle to convert t into u.
         * @return The degree-order derivatives.
         */
        virtual Eigen::VectorXd evaluateDerivative(double t_query, int degree,
                                                   std::function<double(double)> u_handle) = 0;
        /**
         * @brief Gets modifiable waypoints.
         * @return A vector of the modifiable waypoints.
         */
        std::vector<Eigen::VectorXd> &getWaypoints();

        /**
         * @brief Gets unmodifiable waypoints.
         * @return A vector of the unmodifiable waypoints.
         */
        [[nodiscard]] const std::vector<Eigen::VectorXd> &getWaypoints() const;

        /**
         * @brief Gets modifiable time stamps.
         * @return A vector of the modifiable time stamps.
         */
        std::vector<double> &getTimeStamps();

        /**
         * @brief Gets unmodifiable time stamps.
         * @return A vector of the unmodifiable time stamps.
         */
        [[nodiscard]] const std::vector<double> &getTimeStamps() const;

        /**
         * @brief Gets the total duration of the trajectory.
         * @return The total duration of the trajectory in seconds format.
         * @throw CustomException if empty trajectory.
         */
        [[nodiscard]] virtual double getDuration() const = 0;

        /**
         * @brief Re-initializes the whole trajectory with different method parameters but the same waypoints.
         * @param request The method parameters.
         */
        virtual void reInit(const SplineRequestPtr& request) = 0;
    protected:
        /**
         * @brief Computes a basic time stamp distribution using centripetal method.
         *        Generally this is the best method, especially for containing some sharp turns.
         */
        void centripetal();

        /**
         * @brief Computes a basic time stamp distribution using cord method.
         */
        void cord();

        /**
         * @brief Computes a basic time stamp distribution using equally method.
         *        Generally this is the (velocity) fastest method.
         */
        void equally();
    };

} // bot_traj_planner

#endif //DUAL_ARM_APP_SPLINE_BASE_HPP