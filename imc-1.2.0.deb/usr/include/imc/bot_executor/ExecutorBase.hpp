/*
  ************************************************************************\

                               C O P Y R I G H T

    Copyright © 2024 IRMV lab, Shanghai Jiao Tong University, China.
                          All Rights Reserved.

    Licensed under the Creative Commons Attribution-NonCommercial 4.0
    International License (CC BY-NC 4.0).
    You are free to use, copy, modify, and distribute this software and its
    documentation for educational, research, and other non-commercial purposes,
    provided that appropriate credit is given to the original author(s) and
    copyright holder(s).

    For commercial use or licensing inquiries, please contact:
    IRMV lab, Shanghai Jiao Tong University at: https://irmv.sjtu.edu.cn/

                               D I S C L A I M E R

    IN NO EVENT SHALL TRINITY COLLEGE DUBLIN BE LIABLE TO ANY PARTY FOR
    DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING,
    BUT NOT LIMITED TO, LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE
    AND ITS DOCUMENTATION, EVEN IF TRINITY COLLEGE DUBLIN HAS BEEN ADVISED OF
    THE POSSIBILITY OF SUCH DAMAGES.

    TRINITY COLLEGE DUBLIN DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED
    TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
    PURPOSE. THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND TRINITY
    COLLEGE DUBLIN HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
    ENHANCEMENTS, OR MODIFICATIONS.

    The authors may be contacted at the following e-mail addresses:

            YX.E.Z yixuanzhou@sjtu.edu.cn

    Further information about the IRMV and its projects can be found at the ISG web site :

           https://irmv.sjtu.edu.cn/

  \*************************************************************************
 */

#ifndef DUAL_ARM_APP_EXECUTORBASE_HPP
#define DUAL_ARM_APP_EXECUTORBASE_HPP

#include "imc/bot_traj_planner/trajectory_base.hpp"

namespace bot_executor {
    /**
     * @typedef renew_fuc_t
     * @brief A function type that renews a trajectory.
     * @param current_traj The current trajectory.
     * @param renew_time The time to renew the trajectory.
     * @return A unique pointer to the renewed trajectory.
     */
    typedef std::function<bot_traj_planner::TrajectoryUniquePtr(
            const bot_traj_planner::TrajectoryPtr &current_traj, double renew_time)> renew_fuc_t;

    class ExecutorBase {
    public:
        ExecutorBase() = default;

        virtual ~ExecutorBase() = default;

    public:
        /**
         * @brief To send joint position command.
         * @param arm_joint The given arm joint position commands.
         * @param lefthand_joints Left hand joints.
         * @param lefthand_current Left hand current.
         * @param righthand_joints Right hand joints.
         * @param righthand_current Right hand current.
         * @return True if the command is sent successfully.
         */
        virtual bool sendAllServo(const Eigen::VectorXd &arm_joint,
                                  const Eigen::VectorXi &lefthand_joints,
                                  const Eigen::VectorXi &lefthand_current,
                                  const Eigen::VectorXi &righthand_joints,
                                  const Eigen::VectorXi &righthand_current) = 0;

        /**
         * @brief To send joint position command.
         * @param arm_joint The given arm joint position commands.
         * @return True if the command is sent successfully.
         */
        virtual bool sendServo(const Eigen::VectorXd &arm_joint) = 0;

        /**
         * @brief To send hand joint position command.
         * @param lefthand_joints Left hand joints.
         * @param lefthand_current Left hand current.
         * @param righthand_joints Right hand joints.
         * @param righthand_current Right hand current.
         * @return True if the command is sent successfully.
         */
        virtual bool sendHandServo(const Eigen::VectorXi &lefthand_joints,
                                   const Eigen::VectorXi &lefthand_current,
                                   const Eigen::VectorXi &righthand_joints,
                                   const Eigen::VectorXi &righthand_current) = 0;

        /**
         * @brief To execute a trajectory.
         * @param traj Trajectory to be executed.
         * @return Success if executed successfully, otherwise an error code.
         */
        virtual bot_common::ErrorInfo move(bot_traj_planner::TrajectoryPtr traj) = 0;

        /**
         * @brief To execute the current trajectory.
         * @param current_traj The current trajectory.
         * @param renew_time The time to renew the trajectory.
         * @param consecutive True if the execution should be consecutive.
         * @return Success if executed successfully, otherwise an error code.
         */
        virtual bot_common::ErrorInfo
        executeCurrentTrajectory(const bot_traj_planner::TrajectoryPtr &current_traj,
                                 double renew_time, bool consecutive) = 0;

        /**
         * @brief Wait for the current execution to finish.
         * @return Success if finished successfully, otherwise an error code.
         */
        virtual bot_common::ErrorInfo waitForFinish() = 0;

        /**
         * @brief Fetch the current joint values.
         * @return The current joint values.
         * @throw invalidArgument if fetching fails.
         */
        virtual Eigen::VectorXd getCurrentJointValues() = 0;

        /**
         * @brief Fetch the current joint error codes.
         * @return The current joint error codes.
         * @throw invalidArgument if fetching fails.
         */
        virtual Eigen::VectorXf getCurrentJointError() = 0;

        /**
         * @brief Fetch the home joint values.
         * @return The home joint values.
         */
        virtual const Eigen::VectorXd &getHomeJointValues() = 0;

        /**
         * @brief Check if the robot is moving.
         * @return True if the robot is moving.
         */
        virtual bool isMoving() = 0;

        /**
         * @brief Check if the robot is in fault.
         * @return True if the robot is in fault.
         */
        virtual bool isInFault() = 0;

        /**
         * @brief Check if the robot is connected.
         * @return True if the robot is connected. The simulation will always return true.
         */
        virtual bool isConnected() = 0;

        /**
         * @brief Check if the robot is enabled.
         * @return True if the robot is enabled.
         */
        virtual bool isEnabled() = 0;

        /**
         * @brief Get the names of the joints.
         * @return A vector of joint names.
         */
        virtual const std::vector<std::string>& getJointNames() = 0;

        /**
         * @brief Get the control frequency.
         * @return The control frequency.
         */
        virtual int getControlFrequency() = 0;
    };

    /**
     * @typedef ExecutorPtr
     * @brief A shared pointer to an ExecutorBase object.
     */
    typedef std::shared_ptr<ExecutorBase> ExecutorPtr;

    /**
     * @typedef ExecutorUniquePtr
     * @brief A unique pointer to an ExecutorBase object.
     */
    typedef std::unique_ptr<ExecutorBase> ExecutorUniquePtr;
}

#endif //DUAL_ARM_APP_EXECUTORBASE_HPP
