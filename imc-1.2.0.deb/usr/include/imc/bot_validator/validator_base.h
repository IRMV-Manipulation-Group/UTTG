/*
  ************************************************************************\

                               C O P Y R I G H T

    Copyright © 2024 IRMV lab, Shanghai Jiao Tong University, China.
                          All Rights Reserved.

    Licensed under the Creative Commons Attribution-NonCommercial 4.0
    International License (CC BY-NC 4.0).
    You are free to use, copy, modify, and distribute this software and its
    documentation for educational, research, and other non-commercial purposes,
    provided that appropriate credit is given to the original author(s) and
    copyright holder(s).

    For commercial use or licensing inquiries, please contact:
    IRMV lab, Shanghai Jiao Tong University at: https://irmv.sjtu.edu.cn/

                               D I S C L A I M E R

    IN NO EVENT SHALL TRINITY COLLEGE DUBLIN BE LIABLE TO ANY PARTY FOR
    DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING,
    BUT NOT LIMITED TO, LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE
    AND ITS DOCUMENTATION, EVEN IF TRINITY COLLEGE DUBLIN HAS BEEN ADVISED OF
    THE POSSIBILITY OF SUCH DAMAGES.

    TRINITY COLLEGE DUBLIN DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED
    TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
    PURPOSE. THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND TRINITY
    COLLEGE DUBLIN HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
    ENHANCEMENTS, OR MODIFICATIONS.

    The authors may be contacted at the following e-mail addresses:

            YX.E.Z yixuanzhou@sjtu.edu.cn

    Further information about the IRMV and its projects can be found at the ISG web site :

           https://irmv.sjtu.edu.cn/

  \*************************************************************************
 */

/**
 * A general validator interface and van-de-corupt sequence-based collision checking
 * Author: YX.E.Z
 * Date: 2023/7/24
 */
#ifndef BOT_VALIDATOR_H
#define BOT_VALIDATOR_H

#include <memory>
#include <Eigen/Dense>
#include <vector>
#include <irmv/bot_common/state/error_code.h>

namespace bot_validator {
    /**
     * @class ValidatorBase
     * @brief Class for collision checking.
     */
    class ValidatorBase : public std::enable_shared_from_this<ValidatorBase> {
    public:
        /**
         * @brief Default constructor for ValidatorBase.
         */
        explicit ValidatorBase() = default;

        /**
         * @brief Virtual destructor for ValidatorBase.
         */
        virtual ~ValidatorBase() = default;

    public:
        /**
         * @brief Checks path validation for every waypoint in a vector, only checking every single point.
         * @param path A vector of waypoints.
         * @param check_collision True for collision check and limitation check, otherwise limitation check only.
         * @return Error messages.
         */
        bot_common::ErrorInfo
        isPathValidNaive(const std::vector<Eigen::VectorXd> &path, bool check_collision);

        /**
        * @brief Checks path validation for every waypoint in a vector, every segment will be checked in the definition of @min_check_distance.
        * @param path A vector of waypoints.
        * @param min_check_distance The minimum distance checked unit rad.
        * @param check_collision True for collision check and limitation check, otherwise limitation check only.
        * @return Error messages.
        */
        bot_common::ErrorInfo
        isPathValid(const std::vector<Eigen::VectorXd> &path, double min_check_distance, bool check_collision);

        /**
         * @brief Checks path validation from one waypoint to another.
         * @param from The start waypoint.
         * @param to The end waypoint.
         * @param min_check_distance The minimum distance checked unit rad.
         * @param consecutive True for consecutive check, which means the last one is not checked.
         * @param check_collision True for collision check and limitation check, otherwise limitation check only.
         * @return Error messages.
         */
        bot_common::ErrorInfo
        isPathValid(const Eigen::VectorXd &from, const Eigen::VectorXd &to, double min_check_distance,
                    bool consecutive, bool check_collision);

        /**
         * @brief Computes vdc value.
         * @param n The index.
         * @param bits The number of bits to compute vdc sequence.
         * @return vdc value.
         */
        static double vdc(int n, unsigned int bits);

        /**
         * @brief Checks if one single joint waypoint is valid or not.
         * @param joint_values The joint values.
         * @param check_collision True for collision check and limitation check, otherwise limitation check only.
         * @return Error messages for valid waypoint checking.
         */
        virtual bot_common::ErrorInfo isValid(const Eigen::VectorXd &joint_values, bool check_collision);

        /**
         * @brief Checks if one single joint waypoint is in collision or not.
         * @param joint_values The joint values to be checked.
         * @return ErrorCode::InCollision for in collision, otherwise ErrorCode::OK.
         */
        virtual bot_common::ErrorInfo checkCollision(const Eigen::VectorXd &joint_values) = 0;

        /**
         * @brief Checks if joint status is inside limitation range or not.
         * @param joint_values The joint values to be checked.
         * @param velocity_values The joint velocities to be checked.
         * @param acceleration_values The acceleration values to be checked.
         * @return ErrorCode::OutLimitation for out of limitation, otherwise ErrorCode::OK.
         */
        virtual bot_common::ErrorInfo
        checkLimitation(const Eigen::VectorXd &joint_values, const Eigen::VectorXd &velocity_values,
                        const Eigen::VectorXd &acceleration_values) = 0;

        /**
         * @brief Modifies the collision allowed matrix.
         * @param allowed_pairs The allowed pairs of joints.
         * @param enableCollision True to enable collision, false to disable.
         */
        virtual void
        modifyCollisionAllowedMatrix(const std::vector<std::pair<std::string, std::string>> &allowed_pairs,
                                     bool enableCollision) = 0;

        /**
         * @brief Gets the planning group name specified.
         * @return The planning group name.
         */
        virtual const std::string &getPlanningGroupName() = 0;
    };

    typedef std::shared_ptr<ValidatorBase> ValidatorPtr; ///< Shared pointer to ValidatorBase.
    typedef std::unique_ptr<ValidatorBase> ValidatorUniquePtr; ///< Unique pointer to ValidatorBase.
}

#endif //BOT_VALIDATOR_H
