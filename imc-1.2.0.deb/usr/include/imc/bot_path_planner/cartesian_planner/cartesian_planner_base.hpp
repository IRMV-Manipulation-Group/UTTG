/*
  ************************************************************************\

                               C O P Y R I G H T

    Copyright © 2024 IRMV lab, Shanghai Jiao Tong University, China.
                          All Rights Reserved.

    Licensed under the Creative Commons Attribution-NonCommercial 4.0
    International License (CC BY-NC 4.0).
    You are free to use, copy, modify, and distribute this software and its
    documentation for educational, research, and other non-commercial purposes,
    provided that appropriate credit is given to the original author(s) and
    copyright holder(s).

    For commercial use or licensing inquiries, please contact:
    IRMV lab, Shanghai Jiao Tong University at: https://irmv.sjtu.edu.cn/

                               D I S C L A I M E R

    IN NO EVENT SHALL TRINITY COLLEGE DUBLIN BE LIABLE TO ANY PARTY FOR
    DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING,
    BUT NOT LIMITED TO, LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE
    AND ITS DOCUMENTATION, EVEN IF TRINITY COLLEGE DUBLIN HAS BEEN ADVISED OF
    THE POSSIBILITY OF SUCH DAMAGES.

    TRINITY COLLEGE DUBLIN DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED
    TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
    PURPOSE. THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND TRINITY
    COLLEGE DUBLIN HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
    ENHANCEMENTS, OR MODIFICATIONS.

    The authors may be contacted at the following e-mail addresses:

            YX.E.Z yixuanzhou@sjtu.edu.cn

    Further information about the IRMV and its projects can be found at the ISG web site :

           https://irmv.sjtu.edu.cn/

  \*************************************************************************
 */

#ifndef DUAL_ARM_APP_CARTESIAN_PLANNER_BASE_HPP
#define DUAL_ARM_APP_CARTESIAN_PLANNER_BASE_HPP

#include "imc/bot_validator/validator_base.h"
#include "imc/bot_kinematics/kinematics_base.hpp"
#include <memory>
#include <Eigen/Dense>
#include <vector>
#include <algorithm>
#include <chrono>

namespace bot_path_planner {

    class CartesianPlannerBase {
    public:
        /**
         * @brief Constructor for CartesianPlannerBase.
         * @param validatorPtr A shared pointer to a Validator object.
         * @param kinematicsPtr A shared pointer to a Kinematics object.
         */
        CartesianPlannerBase(bot_validator::ValidatorPtr validatorPtr, bot_kinematics::KinematicsPtr kinematicsPtr);

        /**
         * @brief Destructor for CartesianPlannerBase.
         */
        virtual ~CartesianPlannerBase();
    protected:
        double MinConfigCheckDistance {0.01}; ///< Minimum configuration check distance.
        bot_validator::ValidatorPtr val_; ///< Validator pointer.
        bot_kinematics::KinematicsPtr kin_; ///< Kinematics pointer.
    public:
        /**
         * @brief Compute all inverse kinematics (IK) solutions for a given Cartesian path.
         * @warning Collision check is not performed in this function and will be checked later.
         * @param pose_path The given Cartesian path.
         * @param seed The seed, usually the current joints.
         * @param path_IKS Output container for the valid path IKs.
         * @param max_dist The maximum acceptable distance from joint seed to potential IK solutions.
         * @return Success if planning is successful, otherwise an error code indicating why it fails.
         */
        bot_common::ErrorInfo
        computeAllIKPath(const std::vector<Eigen::Isometry3d> &pose_path, const Eigen::VectorXd &seed,
                         std::vector<std::vector<Eigen::VectorXd>> &path_IKS, double max_dist);

        /**
         * @brief Get the nearest valid IK solution for a given query pose.
         * @param query_pose The query pose.
         * @param current_joints The current joint positions.
         * @param solution Output container for the nearest valid IK solution.
         * @return Success if a valid IK solution is found, otherwise an error code.
         */
        bot_common::ErrorInfo
        getNearestValidIK(const Eigen::Isometry3d &query_pose, const Eigen::VectorXd &current_joints,
                          Eigen::VectorXd &solution);

        /**
         * @brief Compute the best IK path for a given Cartesian path.
         * @param pose_path The given Cartesian path.
         * @param seed The seed, usually the current joints.
         * @param dst_joint_path Output container for the joint path corresponding to the Cartesian path.
         * @param jump_threshold The threshold; if exceeded, the joint path planning fails.
         * @param timeout_all The total timeout for the computation.
         * @param checkCollision Flag indicating whether to check for collisions.
         * @return Success if planning is successful, otherwise an error code indicating why it fails.
         */
        virtual bot_common::ErrorInfo
        computeCartesianIKPath(const std::vector<Eigen::Isometry3d> &pose_path, const Eigen::VectorXd &seed,
                               std::vector<Eigen::VectorXd> &dst_joint_path, double jump_threshold, double timeout_all, bool checkCollision);

        /**
         * @brief Search for the shortest path through all valid IKs using a greedy method.
         * @param pose_path All poses.
         * @param seed The seed for the optimization method.
         * @param dst Output container for the search result.
         * @param jump_threshold The threshold; if exceeded, the joint path planning fails.
         * @param checkCollision Flag indicating whether to check for collisions.
         * @return Success if the computation is successful, otherwise an error code indicating why it fails.
         */
        bot_common::ErrorInfo
        greedySearch(const std::vector<Eigen::Isometry3d> &pose_path, const Eigen::VectorXd &seed,
                     std::vector<Eigen::VectorXd> &dst, double jump_threshold, bool checkCollision);

        /**
         * @brief Search for the shortest path through all valid IKs using a backward-iteration method.
         * This method is more robust but slower.
         * @param pose_path All poses.
         * @param seed The seed for the optimization method.
         * @param dst Output container for the search result.
         * @param jump_threshold The threshold; if exceeded, the joint path planning fails.
         * @param timeout_all The total timeout for the computation.
         * @param checkCollision Flag indicating whether to check for collisions.
         * @return Success if the computation is successful, otherwise an error code indicating why it fails.
         */
        bot_common::ErrorInfo
        searchBestPath(const std::vector<Eigen::Isometry3d> &pose_path, const Eigen::VectorXd &seed,
                       std::vector<Eigen::VectorXd> &dst, double jump_threshold, double &timeout_all, bool checkCollision);

        /**
         * @brief Set the minimum configuration check distance.
         * @param val The new minimum configuration check distance.
         */
        void setMinConfigCheckDistance(const double &val);

        /**
         * @brief Get the minimum configuration check distance.
         * @return The minimum configuration check distance.
         */
        [[nodiscard]] double getMinConfigCheckDistance() const;
    protected:
        /**
         * @brief Wrap joint values within limits.
         * @param raw The joint values to be wrapped.
         * @return True if wrapping is successful, otherwise false.
         */
        bool wrap(Eigen::VectorXd& raw);
    };

    /**
     * @typedef CartesianPlannerPtr
     * @brief A shared pointer to a CartesianPlannerBase object.
     */
    typedef std::shared_ptr<CartesianPlannerBase> CartesianPlannerPtr;

    /**
     * @typedef CartesianPlannerUniquePtr
     * @brief A unique pointer to a CartesianPlannerBase object.
     */
    typedef std::unique_ptr<CartesianPlannerBase> CartesianPlannerUniquePtr;
}

#endif //DUAL_ARM_APP_CARTESIAN_PLANNER_BASE_HPP
