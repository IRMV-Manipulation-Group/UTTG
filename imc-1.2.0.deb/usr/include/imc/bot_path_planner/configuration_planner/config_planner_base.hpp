/*
  ************************************************************************\

                               C O P Y R I G H T

    Copyright © 2024 IRMV lab, Shanghai Jiao Tong University, China.
                          All Rights Reserved.

    Licensed under the Creative Commons Attribution-NonCommercial 4.0
    International License (CC BY-NC 4.0).
    You are free to use, copy, modify, and distribute this software and its
    documentation for educational, research, and other non-commercial purposes,
    provided that appropriate credit is given to the original author(s) and
    copyright holder(s).

    For commercial use or licensing inquiries, please contact:
    IRMV lab, Shanghai Jiao Tong University at: https://irmv.sjtu.edu.cn/

                               D I S C L A I M E R

    IN NO EVENT SHALL TRINITY COLLEGE DUBLIN BE LIABLE TO ANY PARTY FOR
    DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING,
    BUT NOT LIMITED TO, LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE
    AND ITS DOCUMENTATION, EVEN IF TRINITY COLLEGE DUBLIN HAS BEEN ADVISED OF
    THE POSSIBILITY OF SUCH DAMAGES.

    TRINITY COLLEGE DUBLIN DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED
    TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
    PURPOSE. THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND TRINITY
    COLLEGE DUBLIN HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
    ENHANCEMENTS, OR MODIFICATIONS.

    The authors may be contacted at the following e-mail addresses:

            YX.E.Z yixuanzhou@sjtu.edu.cn

    Further information about the IRMV and its projects can be found at the ISG web site :

           https://irmv.sjtu.edu.cn/

  \*************************************************************************
 */

//
// Created by zyx on 23-8-27.
//

#ifndef DUAL_ARM_APP_CONFIG_PLANNER_BASE_HPP
#define DUAL_ARM_APP_CONFIG_PLANNER_BASE_HPP

#include "imc/bot_validator/validator_base.h"
#include <memory>
#include <Eigen/Dense>
#include <vector>
#include "imc/bot_kinematics/kinematics_base.hpp"

namespace omplwrap {
    class OmplWrapper;
}

namespace bot_path_planner {

    class ConfigPlannerBase {
    public:
        /**
         * @brief Constructor for ConfigPlannerBase.
         * @param validatorPtr A shared pointer to a Validator object.
         * @param validatorPtr A shared pointer to a Kinematics object.
         */
        explicit ConfigPlannerBase(bot_validator::ValidatorPtr validatorPtr,
                                   const bot_kinematics::KinematicsPtr & = nullptr,
                                   const std::string &planner_name = "RRTConnect");

        /**
         * @brief Destructor for ConfigPlannerBase.
         */
        virtual ~ConfigPlannerBase();

    protected:
        double MinConfigCheckDistance {0.01}; ///< Minimum configuration check distance.
        std::unique_ptr<omplwrap::OmplWrapper> planner_; ///< OmplWrapper pointer.
        bot_validator::ValidatorPtr val_; ///< Validator pointer.
    public:
        /**
         * @brief To plan joint path for joint-space target.
         * @param current_joints The current joint values.
         * @param goal_joints The goal joint values.
         * @param joint_path Output container, a vector of joint values.
         * @param time_out The max allowed planning time.
         * @param checkCollision Flag indicating whether to check for collisions.
         * @return Success for planning successfully, otherwise the enum why it fails.
         */
        bot_common::ErrorInfo planJointPath(const Eigen::VectorXd &current_joints, const Eigen::VectorXd &goal_joints,
                                            std::vector<Eigen::VectorXd> &joint_path, double time_out,
                                            bool checkCollision);

        /**
         * @brief To plan a naive joint path, which linearly connects the start and end in joint space.
         * @param current_joints The current joint positions.
         * @param goal_joints The goal joint positions.
         * @param joint_path Output container.
         * @param checkCollision Flag indicating whether to check for collisions.
         * @return Success for planning successfully, otherwise the enum why it fails.
         */
        bot_common::ErrorInfo
        planNaiveJointPath(const Eigen::VectorXd &current_joints, const Eigen::VectorXd &goal_joints,
                           std::vector<Eigen::VectorXd> &joint_path, bool checkCollision);

        /**
         * @brief To plan a non-trivial path considering collision avoidance (RRT-Connect).
         * @param current_joints The current joint positions.
         * @param goal_joints The goal joint positions.
         * @param joint_path Output container.
         * @param time_out The time allowed to plan.
         * @param checkCollision Flag indicating whether to check for collisions.
         * @return Success for planning successfully, otherwise the enum why it fails.
         */
        virtual bot_common::ErrorInfo
        planNonTrivialJointPath(const Eigen::VectorXd &current_joints, const Eigen::VectorXd &goal_joints,
                                std::vector<Eigen::VectorXd> &joint_path, double time_out, bool checkCollision);

        /**
         * @brief Set the minimum configuration check distance.
         * @param val The new minimum configuration check distance.
         */
        void setMinConfigCheckDistance(const double &val);

        /**
         * @brief Get the minimum configuration check distance.
         * @return The minimum configuration check distance.
         */
        [[nodiscard]] double getMinConfigCheckDistance() const;
    };

    /**
     * @typedef ConfigPlannerPtr
     * @brief A shared pointer to a ConfigPlannerBase object.
     */
    typedef std::shared_ptr<ConfigPlannerBase> ConfigPlannerPtr;

    /**
     * @typedef ConfigPlannerUniquePtr
     * @brief A unique pointer to a ConfigPlannerBase object.
     */
    typedef std::unique_ptr<ConfigPlannerBase> ConfigPlannerUniquePtr;
}

#endif //DUAL_ARM_APP_CONFIG_PLANNER_BASE_HPP
