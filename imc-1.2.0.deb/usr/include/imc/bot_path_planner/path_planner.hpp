/*
  ************************************************************************\

                               C O P Y R I G H T

    Copyright © 2024 IRMV lab, Shanghai Jiao Tong University, China.
                          All Rights Reserved.

    Licensed under the Creative Commons Attribution-NonCommercial 4.0
    International License (CC BY-NC 4.0).
    You are free to use, copy, modify, and distribute this software and its
    documentation for educational, research, and other non-commercial purposes,
    provided that appropriate credit is given to the original author(s) and
    copyright holder(s).

    For commercial use or licensing inquiries, please contact:
    IRMV lab, Shanghai Jiao Tong University at: https://irmv.sjtu.edu.cn/

                               D I S C L A I M E R

    IN NO EVENT SHALL TRINITY COLLEGE DUBLIN BE LIABLE TO ANY PARTY FOR
    DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING,
    BUT NOT LIMITED TO, LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE
    AND ITS DOCUMENTATION, EVEN IF TRINITY COLLEGE DUBLIN HAS BEEN ADVISED OF
    THE POSSIBILITY OF SUCH DAMAGES.

    TRINITY COLLEGE DUBLIN DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED
    TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
    PURPOSE. THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND TRINITY
    COLLEGE DUBLIN HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
    ENHANCEMENTS, OR MODIFICATIONS.

    The authors may be contacted at the following e-mail addresses:

            YX.E.Z yixuanzhou@sjtu.edu.cn

    Further information about the IRMV and its projects can be found at the ISG web site :

           https://irmv.sjtu.edu.cn/

  \*************************************************************************
 */

/**
 * Interface for path planner
 * Author: YX.E.Z
 * Date: 2023/7/25
 */

#ifndef DUAL_ARM_APP_PATH_PLANNER_HPP
#define DUAL_ARM_APP_PATH_PLANNER_HPP

#include "imc/bot_kinematics/kinematics_base.hpp"
#include "configuration_planner/config_planner_base.hpp"
#include "cartesian_planner/cartesian_planner_base.hpp"

namespace bot_path_planner {
    /**
     * @class PathPlanner
     * @brief Interface for path planning functionalities.
     */
    class PathPlanner {
    public:
        /**
         * @brief Constructor for PathPlanner.
         * @param config_planner_name Name of the configuration planner.
         * @param cartesian_planner_name Name of the cartesian planner.
         * @param kinematics_ptr Interface of kinematics function.
         * @param validator_ptr Interface of validation function.
         */
        PathPlanner(const std::string &config_planner_name, const std::string &cartesian_planner_name,
                    bot_kinematics::KinematicsPtr kinematics_ptr, bot_validator::ValidatorPtr validator_ptr);

        /**
         * @brief Destructor for PathPlanner.
         */
        virtual ~PathPlanner();

    protected:
        bot_kinematics::KinematicsPtr kin_; ///< Kinematics interface pointer.
        bot_validator::ValidatorPtr val_; ///< Validator interface pointer.
        bot_path_planner::ConfigPlannerUniquePtr jp_; ///< Unique pointer to configuration planner.
        bot_path_planner::CartesianPlannerUniquePtr cp_; ///< Unique pointer to cartesian planner.

        double MinCartesianTransDistance {0.01}; ///< Minimum cartesian translation distance.
        double MinCartesianAngleDistance {0.01}; ///< Minimum cartesian angle distance.

    public:
        /**
         * @brief Plans a naive joint path, linearly connecting start and end in joint space.
         * @param current_joints The current joint positions.
         * @param goal_joints The goal joint positions.
         * @param joint_path Output container for the joint path.
         * @param checkCollision Flag to check for collisions.
         * @return Success for planning successfully, otherwise the enum why it fails.
         */
        bot_common::ErrorInfo
        planNaiveJointPath(const Eigen::VectorXd &current_joints, const Eigen::VectorXd &goal_joints,
                           std::vector<Eigen::VectorXd> &joint_path, bool checkCollision);

        /**
         * @brief Gets the nearest valid inverse kinematics (IK) solution.
         * @param query_pose The query pose.
         * @param current_joints The current joint positions.
         * @param solution Output container for the nearest valid IK solution.
         * @return OK for success.
         */
        bot_common::ErrorInfo
        getNearestValidIK(const Eigen::Isometry3d &query_pose, const Eigen::VectorXd &current_joints,
                          Eigen::VectorXd &solution);

        /**
         * @brief Solves joint-related problem with joint target.
         * @param path_query Output path.
         * @param current_joints Current joint values.
         * @param goal_joints Goal joint values.
         * @param time_out The max allowed time.
         * @param checkCollision Flag to check for collisions.
         * @return Success for solving successfully, otherwise the enum why it fails.
         */
        bot_common::ErrorInfo solvePTP(std::vector<Eigen::VectorXd> &path_query, const Eigen::VectorXd &current_joints,
                                       const Eigen::VectorXd &goal_joints, double time_out = 1., bool checkCollision=true);

        /**
         * @brief Solves joint-related problem with pose target.
         * @param path_query Output path.
         * @param current_joints Current joint values.
         * @param goal_pose Goal pose.
         * @param time_out The max allowed time.
         * @param checkCollision Flag to check for collisions.
         * @return Success for solving successfully, otherwise the enum why it fails.
         */
        bot_common::ErrorInfo solvePTP(std::vector<Eigen::VectorXd> &path_query, const Eigen::VectorXd &current_joints,
                                       const Eigen::Isometry3d &goal_pose, double time_out = 1., bool checkCollision=true);

        /**
         * @brief Computes the best IK path corresponding to a cartesian path.
         * @param pose_path The given cartesian path.
         * @param seed The seed (usually the current joints).
         * @param dst_joint_path Output container for the joint path corresponding to the cartesian path.
         * @param jump_threshold The threshold, when exceeded the joint path planning fails.
         * @param timeout_all The max allowed time for the entire computation.
         * @param checkCollision Flag to check for collisions.
         * @return Success for planning successfully, otherwise the enum why it fails.
         */
        virtual bot_common::ErrorInfo
        computeCartesianIKPath(const std::vector<Eigen::Isometry3d> &pose_path, const Eigen::VectorXd &seed,
                               std::vector<Eigen::VectorXd> &dst_joint_path, double jump_threshold, double timeout_all, bool checkCollision);

        /**
         * @brief Solves pose-related problem with linear path.
         * @param path_query Output path.
         * @param current_joints Current joint values.
         * @param goal_pose Goal pose.
         * @param jump_threshold The max interval between two waypoints for the IK path.
         * @param timeout_all The max allowed time for the entire computation.
         * @param checkCollision Flag to check for collisions.
         * @return Success for solving successfully, otherwise the enum why it fails.
         */
        bot_common::ErrorInfo
        solveLIN(std::vector<Eigen::VectorXd> &path_query, const Eigen::VectorXd &current_joints,
                 const Eigen::Isometry3d &goal_pose, const double &jump_threshold = 0.2, const double &timeout_all = 5, bool checkCollision=true);

        /**
         * @brief Solves pose-related problem with linear path.
         * @param path_query Output path.
         * @param current_joints Current joint values.
         * @param goal_joints Goal joints.
         * @param jump_threshold The max interval between two waypoints for the IK path.
         * @param timeout_all The max allowed time for the entire computation.
         * @param checkCollision Flag to check for collisions.
         * @return Success for solving successfully, otherwise the enum why it fails.
         */
        bot_common::ErrorInfo
        solveLIN(std::vector<Eigen::VectorXd> &path_query, const Eigen::VectorXd &current_joints,
                 const Eigen::VectorXd &goal_joints, const double &jump_threshold = 0.2, const double &timeout_all = 5, bool checkCollision=true);

        /**
         * @brief Solves circular path-related problem.
         * @warning The rotation vector must be orthogonal to the (first point - center).
         * @param path_query Output path.
         * @param current_joints Current joint values.
         * @param center The given circular center.
         * @param rotation_vector The circular angle and rotation axis (positive in anti-clockwise direction), defined in the base frame.
         * @param jump_threshold The max interval between two waypoints for the IK path.
         * @param timeout_all The max allowed time for the entire computation.
         * @param checkCollision Flag to check for collisions.
         * @return Success for solving successfully, otherwise the enum why it fails.
         */
        bot_common::ErrorInfo
        solveCirc(std::vector<Eigen::VectorXd> &path_query, const Eigen::VectorXd &current_joints,
                  const Eigen::Vector3d &center, const Eigen::AngleAxisd &rotation_vector, double jump_threshold=0.2, double timeout_all=5, bool checkCollision=true);

        /**
         * @brief Plans a cartesian path connecting start and end.
         * @param current_joints The current joint values.
         * @param goal_pose The goal pose.
         * @param pose_path Output container for the path connecting start and end.
         * @param min_trans The minimum discrete distance in the translation dimension.
         * @param min_angle The minimum discrete angle in the rotation dimension.
         * @return Success for planning successfully, otherwise the enum why it fails.
         */
        bot_common::ErrorInfo
        computeLinePath(const Eigen::VectorXd &current_joints, const Eigen::Isometry3d &goal_pose,
                        std::vector<Eigen::Isometry3d> &pose_path, const double &min_trans, const double &min_angle);

        /**
         * @brief Plans a cartesian path connecting start and end.
         * @param current_pose The current pose corresponding to the current joint values.
         * @param goal_pose The goal pose.
         * @param pose_path Output container for the path connecting start and end.
         * @param min_trans The minimum discrete distance in the translation dimension.
         * @param min_angle The minimum discrete angle in the rotation dimension.
         * @return Success for planning successfully, otherwise the enum why it fails.
         */
        bot_common::ErrorInfo
        computeLinePath(const Eigen::Isometry3d &current_pose, const Eigen::Isometry3d &goal_pose,
                        std::vector<Eigen::Isometry3d> &pose_path, const double &min_trans, const double &min_angle);

        /**
         * @brief Plans a circular path considering only the translation part, keeping the orientation constant.
         * @param current_joints The current joints.
         * @param center The given circular center.
         * @param rotation_vector The circular angle and rotation axis (positive in anti-clockwise direction), defined in the base frame.
         * @param pose_path Output container for the path.
         * @return Success for planning successfully, otherwise the enum why it fails.
         */
        bot_common::ErrorInfo
        computeCircPath(const Eigen::VectorXd &current_joints, const Eigen::Vector3d &center,
                        const Eigen::AngleAxisd &rotation_vector,
                        std::vector<Eigen::Isometry3d> &pose_path);

        /**
         * @brief Plans a circular path considering only the translation part, keeping the orientation constant.
         * @param current_pose The current pose corresponding to the current joints.
         * @param center The given circular center.
         * @param rotation_vector The circular angle and rotation axis (positive in anti-clockwise direction), defined in the base frame.
         * @param pose_path Output container for the path.
         * @return Success for planning successfully, otherwise the enum why it fails.
         */
        bot_common::ErrorInfo
        computeCircPath(const Eigen::Isometry3d &current_pose, const Eigen::Vector3d &center,
                        const Eigen::AngleAxisd &rotation_vector,
                        std::vector<Eigen::Isometry3d> &pose_path);

        /**
         * @brief Sets the minimum configuration-space check distance.
         * @param value The value of minimum configuration-space check distance.
         */
        void setMinConfigCheckDistance(double value);

        /**
         * @brief Gets the minimum configuration-space check distance.
         * @return The stored minimum configuration-space check distance, if not set returns default value.
         */
        [[nodiscard]] double getMinConfigCheckDistance() const;

        /**
         * @brief Sets the minimum cartesian-space translation distance.
         * @param value The value of minimum cartesian-space translation check distance.
         */
        void setMinCartesianTransDistance(double value);

        /**
         * @brief Gets the minimum cartesian-space translation distance.
         * @return The stored minimum cartesian-space translation distance, if not set returns default value.
         */
        [[nodiscard]] double getMinCartesianTransDistance() const;

        /**
         * @brief Sets the minimum cartesian-space angle distance.
         * @param value The value of minimum cartesian angle check distance.
         */
        void setMinCartesianAngleDistance(double value);

        /**
         * @brief Gets the minimum cartesian-space angle distance.
         * @return The stored minimum cartesian-space angle distance, if not set returns default value.
         */
        [[nodiscard]] double getMinCartesianAngleDistance() const;
    };

    typedef std::shared_ptr<PathPlanner> PathPlannerPtr; ///< Shared pointer to PathPlanner.
    typedef std::unique_ptr<PathPlanner> PathPlannerUniquePtr; ///< Unique pointer to PathPlanner.
}

#endif //DUAL_ARM_APP_PATH_PLANNER_HPP